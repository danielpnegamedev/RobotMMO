using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

public class HudSkillTreePanelView : MonoBehaviour
{
    public TextMeshProUGUI archetypeTxt;
    public Image archetypeImg;
    public Transform tierSContent;
    public Transform tierAContent;
    public Transform tierBContent;




   
}
