using UnityEngine;
using System.Collections.Generic;
using System;
using System.Linq;
using UnityEngine.Events;
using UnityEngine.UI;
using System.Collections;
public class Attributes : MonoBehaviour
{
   
}
[System.Serializable]
public class HudSkillsInfo
{
    public Sprite sprite;
    public string skillName;
    public string description;
}